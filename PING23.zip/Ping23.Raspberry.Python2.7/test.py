import pyttsx
engine=pyttsx.init('espeak')
engine.say('good morning')
engine.runAndWait()
