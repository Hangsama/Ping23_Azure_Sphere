import snowboydecoder
import sys
import signal
import speech_recognition as sr
import pyttsx3
import os
import serial
import threading
import nltk
from nltk.corpus import stopwords
import multiprocessing as mp

"""
This demo file shows you how to use the new_message_callback to interact with
the recorded audio after a keyword is spoken. It uses the speech recognition
library in order to convert the recorded audio into text.

Information on installing the speech recognition library can be found at:
https://pypi.python.org/pypi/SpeechRecognition/
"""


interrupted = False


def audioRecorderCallback(fname):
    print "converting audio to text"
    r = sr.Recognizer()
    q=mp.Queue()
    with sr.AudioFile(fname) as source:
        audio = r.record(source,offset=0.5)  # read the entire audio file
        r.adjust_for_ambient_noise(source,1)
        thread = threading.Thread(target=snowboydecoder.play_audio_file,args=("resources/dong.wav",))
        thread.start()
        #snowboydecoder.play_audio_file("resources/dong.wav")
    # recognize speech using Azure Speech Recognition
    try:
        # for testing purposes, we're just using the default API key
        # to use another API key, use `r.recognize_google(audio, key="GOOGLE_SPEECH_RECOGNITION_API_KEY")`
        # instead of `r.recognize_google(audio)`
        AZURE_KEY = "de6c79fa82024c3c9b38c6edc07b94c3"
        contenu=r.recognize_bing(audio,key=AZURE_KEY)
       
        '''
        p = mp.Process(target = sentenceAnalysis,args=(q,contenu.lower()))
        p.start()
        realText = q.get()
        '''
        words = contenu.lower()
        print(contenu)
        message = sentenceAnalysis1(words)
        print(message)
        if (message == 'help'):
            engine.say('I can help you when you need me. For example, I can turn on the light when you say turn on the light or I can tell you the temperture')
            engine.runAndWait()
        elif (message =='lightOn'):
            engine.say('ok, wait a moment')
            engine.runAndWait()
        elif (message=='lightOff'):
            engine.say('ok, wait a moment')
            engine.runAndWait()
        elif (message == 'tempT'):
            engine.say('the temperture of today will be 20 degre')
            engine.runAndWait()
        elif (message == 'tempTo'): 
            engine.say('the temperture of tomorrow will be 25 degre')
            engine.runAndWait()
        elif (message == 'tempWh'):
            engine.say("Please precise which day's temperture do you want")
            engine.runAndWait()
        elif (message =='noIdea') :
            engine.say('sorry, we have not yeah developpe this part. For more functionality, please wait for the update next time') 
            engine.runAndWait() 
    except sr.UnknownValueError:
        print "Azure Speech Recognition could not understand audio"
        engine.say('sorry, I do not understand what you want to say')
        engine.runAndWait()
    except sr.RequestError as e:
        print "Could not request results from Azure Speech Recognition service; {0}".format(e)
        engine.say('sorry, I can not connect to the Azure cloud. Please check the wifi connection')
        engine.runAndWait()
   
    os.remove(fname)

def sentenceAnalysis1 (sentence): 
    words = nltk.word_tokenize(sentence)
    if ('do' in words or 'help' in words):
        if('can' in words and 'you' in words):
            message='help'
        else : message='noIdea'    
    
    elif('light' in words):
        if('on' in words): 
            message= 'lightOn'
        elif('off' in words):
            message = 'lightOff'
        else: message='noIdea'
    elif ('temperature' in words): 
        if('today' in words): 
            message='tempT'
        elif('tomorrow' in words): 
            message='tempTo'
        else : message = 'tempWh'
    else: message = 'noIdea'
    
    return message
'''
def sentenceAnalysis(q,sentence):
    noum = []
    verb = []
    question = []
    model = []
    pratical=[]
    message=''
    #main thread
    words = nltk.word_tokenize(sentence)
    word_tag = nltk.pos_tag(words)
    

    for i in range(len(word_tag)):
        if(word_tag[i][1]=='NN' or word_tag[i][1]=='NNS' or word_tag[i][1]== 'NNP' or word_tag[i][1]== 'NNPS'):
            if(word_tag[i][0] not in noum):
                noum.append( word_tag[i][0])
        elif(word_tag[i][1]=='VB' or word_tag[i][1]=='VBZ' or word_tag[i][1]=='VBP' or word_tag[i][1]=='VBD' ):
            if(word_tag[i][0] not in verb):
                verb.append( word_tag[i][0])
        elif(word_tag[i][1]=='WP' or word_tag[i][1]=='WDT' or word_tag[i][1]=='WP$' or word_tag[i][1]=='WRB' ):
            if(word_tag[i][0] not in question):
                question.append(word_tag[i][0])
        elif(word_tag[i][1]=='MD'):
            if(word_tag[i][0] not in model):
                model.append( word_tag[i][0])
        elif(word_tag[i][1]=='RP' or word_tag[i][1]=='IN'):
            if(word_tag[i][0] not in model):
                pratical.append( word_tag[i][0])

    if('light' in noum):
        if('turn' in noum or 'turn' in verb): 
            if('on' in pratical ):
                message='turn on the light'
            elif('off' in pratical):
                message='turn off the light'
            else: 
                message='sorry'
        else: message='sorry'


    if('door' in noum):
        if('open' in verb ):
            message='open the door'
        elif('close' in verb):
            message='close the door'
        else:message='sorry'


    if('window' in noum):
        if('open' in verb ):
            message='open the window'
        elif('close' in verb):
            message='close the window'
        else:message='sorry'
         
    if('what' in question):
        if('can' in model):
            message='what can you do'
        elif('temperture' in noum):
            message='actual temperture'
        else:message='sorry'
    if('help' in verb or 'help' in noum):
        message='what can you do'
    q.put(message)
'''

def detectedCallback():
  sys.stdout.write("recording audio...")
  sys.stdout.flush()
  snowboydecoder.play_audio_file("resources/dong.wav")
 

def signal_handler(signal, frame):
    global interrupted
    interrupted = True


def interrupt_callback():
    global interrupted
    return interrupted

'''if len(sys.argv) == 1:
    print "Error: need to specify model name"
    print "Usage: python demo.py your.model"
    sys.exit(-1)
'''
#I have already train my model for the starting word, change the file name to your own model
model = 'ok_azure.pmdl'

# capture SIGINT signal, e.g., Ctrl+C
signal.signal(signal.SIGINT, signal_handler)
#initialize the spearking engine and set the speaking rate
engine=pyttsx3.init('espeak')
engine.setProperty('rate',150)

#Initilize the serial communication
#ser = serial.Serial(port='/dev/ttyS0',baudrate = 9600)

detector = snowboydecoder.HotwordDetector(model, sensitivity=0.51)
print "Listening... Press Ctrl+C to exit"

# main loop
detector.start(detected_callback=detectedCallback,
               audio_recorder_callback=audioRecorderCallback,
               interrupt_check=interrupt_callback,
               sleep_time=0.1,
               recording_timeout=12)

detector.terminate()




