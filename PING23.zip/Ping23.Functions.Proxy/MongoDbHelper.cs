﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using MongoDB.Driver;
using System.Security.Authentication;
using System.Net;

namespace Ping23.Functions.Proxy
{
    internal static class MongoDbHelper
    {
        // envoyer des données à une collection MongoDB à partir d'une requête http
        public static async Task<IActionResult> Send<TCollection>(string collectionName, HttpRequest request, ILogger log)
        {
            // récupère les paramètres à partir des variables d'environement
            var connectionString = Environment.GetEnvironmentVariable("MongoDb.ConnectionString");
            var databaseName = Environment.GetEnvironmentVariable("MongoDb.DatabaseName");
            var settings = MongoClientSettings.FromConnectionString(connectionString);

            // cosmosDB requiert l'utilisation de SSL
            settings.SslSettings = new SslSettings() { EnabledSslProtocols = SslProtocols.Tls12 };

            try
            {
                // connexion à mongoDB
                var mongoClient = new MongoClient(settings);
                var db = mongoClient.GetDatabase(databaseName);
                var collection = db.GetCollection<TCollection>(collectionName);

                // lecture et déserialization du corps de la requête
                using (var reader = new StreamReader(request.Body))
                {
                    var json = await reader.ReadToEndAsync();

                    log.LogInformation("Processing: " + json);

                    try
                    {
                        var data = JsonConvert.DeserializeObject<TCollection[]>(json);

                        // insertion dans la collection
                        await collection.InsertManyAsync(data);

                        return new OkResult();
                    }
                    catch (Exception e)
                    {
                        return new BadRequestObjectResult(e.Message);
                    }
                }
            }
            catch (Exception e)
            {
                log.LogError(e.Message);

                return new ObjectResult(e.Message)
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }
    }
}
