﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Azure.EventHubs;
using Microsoft.Azure.EventHubs.Processor;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Ping23.Common.Model;
using Ping23.Web.App.Hubs;

namespace Ping23.Web.App.Services
{
    public class EventHubListener : IEventProcessor
    {
        private readonly IHubContext<NotificationHub> _hub;
        private readonly ILogger<EventHubListener> _logger;

        public EventHubListener(IHubContext<NotificationHub> hub, ILogger<EventHubListener> logger)
        {
            _hub = hub;
            _logger = logger;
        }

        public async Task ProcessEventsAsync(PartitionContext context, IEnumerable<EventData> messages)
        {
            // notifie les clients signalR à la réception d'un message depuis IoT Hub

            var platformMessages = messages
                .Select(message =>
                {
                    var bytes = message.Body.ToArray();
                    var json = Encoding.UTF8.GetString(bytes);

                    try
                    {
                        return JsonConvert.DeserializeObject<PlatformMessage<object>>(json);
                    }
                    catch
                    {
                        return null;
                    }
                })
                .Where(x => x != null)
                .ToArray();

            _logger.LogInformation($"Received {platformMessages.Length} messages from IoT Hub.");

            await _hub.Clients.All.SendAsync("notify", platformMessages);
        }

        public Task CloseAsync(PartitionContext context, CloseReason reason) => Task.CompletedTask;

        public Task OpenAsync(PartitionContext context) => Task.CompletedTask;

        public Task ProcessErrorAsync(PartitionContext context, Exception error)
        {
            _logger.LogError(error.Message);

            return Task.CompletedTask;
        }
    }
}
