using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.AzureAD.UI;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SpaServices.AngularCli;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Ping23.Web.App.Misc;
using Ping23.Common.Providers.MongoDB;
using Ping23.Common.Managers.Mongo;
using Ping23.Common.Managers;
using Ping23.Web.App.Hubs;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Authorization;
using Ping23.Web.App.Services;
using Microsoft.Azure.EventHubs.Processor;
using Ping23.Common.Model.Misc;
using Ping23.Common.Utils;

namespace Ping23.Web.App
{
    public class Startup
    {
        public readonly IConfiguration Configuration;

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            var eventHubSettings = Configuration.GetSection(nameof(EventHubSettings)).Get<EventHubSettings>();
            var mongoDbSettings = Configuration.GetSection(nameof(MongoDbSettings)).Get<MongoDbSettings>();
            var iotHubSettings = Configuration.GetSection(nameof(IoTHubSettings)).Get<IoTHubSettings>();
            var redisSettings = Configuration.GetSection(nameof(RedisSettings)).Get<RedisSettings>();

            services.Configure<CookiePolicyOptions>(options =>
            {
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            services.AddAuthentication(AzureADDefaults.AuthenticationScheme)
                .AddAzureAD(options => Configuration.Bind("AzureAd", options));

            services.Configure<OpenIdConnectOptions>(AzureADDefaults.OpenIdScheme, options =>
            {
                options.Authority = options.Authority + "/v2.0/";
                options.TokenValidationParameters.ValidateIssuer = false;
            });

            services.AddMvc(options =>
            {
                var policy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .Build();
                options.Filters.Add(new AuthorizeFilter(policy));
            }).SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
            services.AddSignalR();

            services.AddSpaStaticFiles(configuration => configuration.RootPath = "ClientApp/dist");

            services.AddLogging();

            services.AddSingleton(eventHubSettings);
            services.AddSingleton(mongoDbSettings);
            services.AddSingleton(iotHubSettings);
            services.AddSingleton(redisSettings);

            services.AddScoped<MongoDbProvider>();
            services.AddScoped<ICommandManager, CommandManager>();
            services.AddScoped<IReadingManager, ReadingManager>();
            services.AddScoped<IRuleManager, RuleManager>();

            services.AddSingleton<MessageSender>();
            services.AddScoped<EventHubListener>();
            services.AddSingleton<EventHubListenerFactory>();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env, IApplicationLifetime lifetime, 
            EventHubListenerFactory eventHubListenerFactory, EventHubSettings eventHubSettings)
        {
            if (env.IsDevelopment())
                app.UseDeveloperExceptionPage();
            else
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseSpaStaticFiles();

            app.UseCookiePolicy();
            app.UseAuthentication();

            app.UseSignalR(routes => routes.MapHub<NotificationHub>("/hubs/notifications"));

            app.UseMvc(routes =>
                routes.MapRoute(
                    name: "default",
                    template: "{controller}/{action=Index}/{id?}"));

            app.Use(async (context, next) =>
            {
                if (!context.User.Identity.IsAuthenticated)
                    await context.ChallengeAsync(AzureADDefaults.AuthenticationScheme);
                else await next();
            });

            app.UseSpa(spa =>
            {
                spa.Options.SourcePath = "ClientApp";
                if (env.IsDevelopment()) spa.UseAngularCliServer(npmScript: "start");
            });

            ConfigureEventHubListener(lifetime, eventHubListenerFactory, eventHubSettings);
        }

        private void ConfigureEventHubListener(IApplicationLifetime lifetime, EventHubListenerFactory eventHubListenerFactory, EventHubSettings eventHubSettings)
        {
            var eventProcessorHost = new EventProcessorHost(
                eventHubSettings.Name,
                eventHubSettings.ConsumerGroup,
                eventHubSettings.ConnectionString,
                eventHubSettings.StorageConnectionString,
                eventHubSettings.StorageContainerName);

            eventProcessorHost.RegisterEventProcessorFactoryAsync(eventHubListenerFactory).Wait();

            lifetime.ApplicationStopped.Register(() => eventProcessorHost.UnregisterEventProcessorAsync().Wait());
        }
    }
}
