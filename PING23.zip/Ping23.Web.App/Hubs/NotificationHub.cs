﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace Ping23.Web.App.Hubs
{
    [Authorize]
    public class NotificationHub : Hub { }
}
