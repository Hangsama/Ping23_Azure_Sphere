﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Ping23.Common.Managers;
using System;
using System.Net;
using System.Threading.Tasks;

namespace Ping23.Web.App.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    public class ReadingController : Controller
    {
        private readonly IReadingManager _readingManager;
        private readonly ILogger<ReadingController> _logger;

        public ReadingController(ILogger<ReadingController> logger, IReadingManager readingManager)
        {
            _logger = logger;
            _readingManager = readingManager;
        }

        [HttpGet]
        public async Task<IActionResult> Get(long startTimestamp, long endTimestamp, string types, bool forceRenew = false)
        {
            try
            {
                var result = types == null
                    ? await _readingManager.Get(startTimestamp, endTimestamp, forceRenew)
                    : await _readingManager.Get(startTimestamp, endTimestamp, types.Split(','), forceRenew);

                return Ok(result);
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }
    }
}
