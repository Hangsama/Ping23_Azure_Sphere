﻿using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Devices;
using Microsoft.Extensions.Logging;
using Ping23.Common.Model.Misc;

namespace Ping23.Web.App.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    public class DeviceController : ControllerBase
    {
        private readonly RegistryManager _registryManager;
        private readonly ILogger<DeviceController> _logger;

        public DeviceController(IoTHubSettings iotHubSettings, ILogger<DeviceController> logger)
        {
            _registryManager = RegistryManager.CreateFromConnectionString(iotHubSettings.ConnectionString);
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                // récupère les devices à l'aide de IoT Hub Registry Manager

#pragma warning disable CS0618
                var devices = await _registryManager.GetDevicesAsync(int.MaxValue);
#pragma warning restore CS0618

                return Ok(devices.Select(device => new
                {
                    device.Id,
                    device.StatusReason,
                    ConnectionState = device.ConnectionState.ToString().ToLower(),
                    Status = device.Status.ToString().ToLower(),
                    ConnectionStateUpdatedTime =
                        device.ConnectionStateUpdatedTime == default ? 0 :
                        new DateTimeOffset(device.ConnectionStateUpdatedTime).ToUnixTimeMilliseconds(),
                    LastActivityTime =
                        device.LastActivityTime == default ? 0 :
                        new DateTimeOffset(device.LastActivityTime).ToUnixTimeMilliseconds(),
                    StatusUpdatedTime =
                        device.StatusUpdatedTime == default ? 0 :
                        new DateTimeOffset(device.StatusUpdatedTime).ToUnixTimeMilliseconds()
                }));
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }
    }
}