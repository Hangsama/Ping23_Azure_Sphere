﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Ping23.Common.DTO.Rules;
using Ping23.Common.Managers;
using System;
using System.Net;
using System.Threading.Tasks;

namespace Ping23.Web.App.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    public class RuleController : Controller
    {
        private readonly IRuleManager _manager;
        private readonly ILogger<ReadingController> _logger;

        public RuleController(ILogger<ReadingController> logger, IRuleManager manager)
        {
            _logger = logger;
            _manager = manager;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll(bool forceRenew = false)
        {
            try
            {
                return Ok(await _manager.GetAll(forceRenew));
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(string id, bool forceRenew = false)
        {
            try
            {
                var result = await _manager.Get(id, forceRenew);

                return result == null ? NotFound() : Ok(result) as IActionResult;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Rule rule)
        {
            try
            {
                return Ok(await _manager.Create(rule));
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPut]
        public async Task<IActionResult> Update([FromBody] Rule rule)
        {
            try
            {
                return Ok(await _manager.Update(rule));
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            try
            {
                return Ok(await _manager.Delete(id));
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }
    }
}
