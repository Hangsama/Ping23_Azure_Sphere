﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Devices;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Ping23.Common.Managers;
using Ping23.Common.Model;
using Ping23.Common.Model.Misc;
using Ping23.Common.Utils;
using Ping23.Rules.Engine;
using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Ping23.Web.App.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    public class CommandController : Controller
    {
        private readonly ILogger<CommandController> _logger;
        private readonly IoTHubSettings _iotHubSettings;
        private readonly ICommandManager _commandManager;
        private readonly IRuleManager _ruleManager;
        private readonly MessageSender _messageSender;

        public CommandController(
            ILogger<CommandController> logger, IoTHubSettings iotHubSettings,
            ICommandManager commandManager, IRuleManager ruleManager,
            MessageSender messageSender)
        {
            _logger = logger;
            _iotHubSettings = iotHubSettings;
            _commandManager = commandManager;
            _ruleManager = ruleManager;
            _messageSender = messageSender;
        }

        [HttpGet]
        public async Task<IActionResult> Get(long startTimestamp, long endTimestamp, bool forceRenew = false)
        {
            try
            {
                var result = await _commandManager.Get(startTimestamp, endTimestamp, forceRenew);
                return Ok(result);
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("_sendMessage")]
        public async Task<IActionResult> SendMessage([FromQuery] string message)
        {
            try
            {
                // instantie le moteur de règles
                var rules = await _ruleManager.GetAll();
                var engine = new RuleEngine(rules);
                var actions = engine.Feed(JToken.FromObject(new PlatformMessage<string>
                {
                    Origin = "Web",
                    Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                    Type = MessageType.CloudMessage.ToString(),
                    Data = message
                })).ToArray();

                await Task.WhenAll(actions.Select(_messageSender.Run));

                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("_sendCommand")]
        public async Task<IActionResult> SendCommand([FromBody] PlatformMessage<object> body)
        {
            try
            {
                await _messageSender.Send(body);

                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);

                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }
    }
}
