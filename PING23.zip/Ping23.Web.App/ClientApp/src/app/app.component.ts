import { Component, ApplicationRef } from '@angular/core';
import { LocalizationService, NotificationService } from '../shared';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  private _language;

  constructor(
    public readonly loc: LocalizationService,
    public readonly notificationSvc: NotificationService) {
    // récupère la langue précédemment définie depuis le localStorage, ou anglais par défaut

    this._language = localStorage.getItem("language") || "english";

    notificationSvc.start();
    loc.language = this._language;
  }

  public get language(): string {
    return this._language;
  }

  public set language(value: string) {
    localStorage.setItem("language", value);
    location.reload();
  }
}
