import { Component } from '@angular/core';
import { Device, LocalizationService, DeviceService } from '../../shared';

@Component({
  selector: 'fleet',
  templateUrl: './fleet.component.html',
  styleUrls: ['./fleet.component.css']
})
export class FleetComponent {
  public loading = true;
  public readonly devices: Device[] = [];

  constructor(
    public readonly loc: LocalizationService,
    private readonly deviceSvc: DeviceService) {
    this.reload();
  }

  private async reload() {
    const devices = await this.deviceSvc.getAll();

    this.devices.length = 0;
    this.devices.push(...devices);
    
    this.loading = false;
  }

  public getTimeString(timestamp: number): string {
    return new Date(timestamp).toLocaleString(this.loc.str("_locale"));
  }
}
