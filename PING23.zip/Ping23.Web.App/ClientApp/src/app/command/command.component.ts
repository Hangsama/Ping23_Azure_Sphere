import { Component, OnDestroy } from '@angular/core';
import { LocalizationService, CommandService, SpeechService } from '../../shared';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'command',
  templateUrl: './command.component.html',
  styleUrls: ['./command.component.css']
})
export class CommandComponent implements OnDestroy {
  public temperatureInput: number = 19;
  public spokenText?: string;
  public sending?: boolean;
  private readonly speechSubscription: Subscription;

  constructor(
    public readonly loc: LocalizationService,
    public readonly speechSvc: SpeechService,
    private readonly commandSvc: CommandService) {
    this.speechSubscription = speechSvc.onRecognition.subscribe(async text => await this.onRecognition(text));
  }

  ngOnDestroy() {
    this.speechSubscription.unsubscribe();
  }

  private async onRecognition(text: string) {
    this.spokenText = text;
    this.sending = true;
    await this.commandSvc.sendMessage(text);
    this.sending = false;
  }

  public async setLight(state: boolean) {
    this.sending = true;
    await this.commandSvc.sendCommand({
      origin: "Web",
      timestamp: Date.now(),
      type: "CloudCommand",
      data: {
        type: "SetLight",
        value: state ? 1 : 0
      }
    });
    this.sending = false;
  }

  public async setAlarm(state: boolean) {
    this.sending = true;
    await this.commandSvc.sendCommand({
      origin: "Web",
      timestamp: Date.now(),
      type: "CloudCommand",
      data: {
        type: "SetAlarm",
        value: state ? 1 : 0
      }
    });
    this.sending = false;
  }

  public async setDoor(state: boolean) {
    this.sending = true;
    await this.commandSvc.sendCommand({
      origin: "Web",
      timestamp: Date.now(),
      type: "CloudCommand",
      data: {
        type: "SetDoor",
        value: state ? 1 : 0
      }
    });
    this.sending = false;
  }

  public async setThermostatValue() {
    this.sending = true;
    await this.commandSvc.sendCommand({
      origin: "Web",
      timestamp: Date.now(),
      type: "CloudCommand",
      data: {
        type: "SetThermostatValue",
        value: this.temperatureInput
      }
    });
    this.sending = false;
  }
}
