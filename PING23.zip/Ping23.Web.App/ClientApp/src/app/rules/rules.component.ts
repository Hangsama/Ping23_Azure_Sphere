import { Component } from "@angular/core";
import { RuleService, Rule, LocalizationService, Condition, Action } from "../../shared";

@Component({
  selector: "rules",
  templateUrl: "./rules.component.html",
  styleUrls: ["./rules.component.css"]
})
export class RulesComponent {
  public readonly rules: Rule[] = [];
  public selected: Rule;
  public loading = false;

  constructor(
    private readonly rulesSvc: RuleService,
    public readonly loc: LocalizationService) {
    this.reload();
  }

  public async reload() {
    this.loading = true;

    const rules = await this.rulesSvc.getAll();

    this.rules.length = 0;
    this.rules.push(...rules);
    this.loading = false;
  }

  public create() {
    if (this.selected != null && this.selected.id == null && !confirm(this.loc.str("rules_unsaved_confirm"))) return;

    this.selected = {
      id: null,
      name: "",
      conditions: [],
      actions: []
    };
  }

  public select(rule: Rule) {
    if (this.selected != null && this.selected.id == null && !confirm(this.loc.str("rules_unsaved_confirm"))) return;

    this.selected = rule;
  }

  public async delete() {
    if (!confirm(this.loc.str("rules_delete_confirm"))) return;

    await this.rulesSvc.delete(this.selected.id);
    this.selected = null;
    await this.reload();
  }

  public async submit() {
    // transforme les chaines numériques en number
    this.selected.conditions.filter(c => c.value.value && !isNaN(c.value.value)).forEach(c => c.value.value = +c.value.value);
    this.loading = true;

    if (this.selected.id != null)
      await this.rulesSvc.update(this.selected);
    else {
      const id = await this.rulesSvc.create(this.selected);

      this.selected.id = id;
    }

    await this.reload();
  }

  public addCondition() {
    this.selected.conditions.push({
      key: "ValueEq",
      value: {
        key: null,
        value: null
      }
    });
  }

  public addAction() {
    this.selected.actions.push({
      key: "SendMessage",
      value: null
    });
  }

  public setConditionType(condition: Condition, type: string) {
    condition.key = type;

    switch (type) {
      case "ValueEq":
      case "ValueLt":
      case "ValueLte":
      case "ValueGt":
      case "ValueGte":
      case "ValueMatches":
        condition.value = {
          key: null,
          value: null
        };
        break;
    }
  }

  public setActionType(action: Action, type: string) {
    action.key = type;

    switch (type) {
      case "SetLight":
      case "SetAlarm":
      case "SetDoor":
        action.value = 1;
        break;
      case "SetThermostatValue":
        action.value = 19;
        break;
    }
  }
}
