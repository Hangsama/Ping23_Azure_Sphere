import { Component, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
import { PlatformMessage, CommandChartComponent, PresenceChartComponent, HumidityChartComponent, LocalizationService, CommandService, NotificationService, ReadingMessage, ReadingService } from '../../shared';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnDestroy, AfterViewInit {
  @ViewChild("commandChart") private commandChart: CommandChartComponent;
  @ViewChild("presenceChart") private presenceChart: PresenceChartComponent;
  @ViewChild("temperatureChart") private temperatureChart: CommandChartComponent;
  @ViewChild("humidityChart") private humidityChart: HumidityChartComponent;

  private _startTimestamp: number = Date.now() - 1000 * 3600 * 24;
  private _endTimestamp: number = Date.now();
  private loading = false;

  public commandData: PlatformMessage[] = [];
  public presenceData: PlatformMessage[] = [];
  public temperatureData: PlatformMessage[] = [];
  public humidityData: PlatformMessage[] = [];

  private readonly notificationSubscription: Subscription;

  constructor(
    public readonly loc: LocalizationService,
    private readonly commandSvc: CommandService,
    private readonly readingSvc: ReadingService,
    private readonly notificationSvc: NotificationService) {
    this.notificationSubscription = notificationSvc.onNotification.subscribe(messages => this.onNotification(messages));
  }

  ngOnDestroy() {
    this.notificationSubscription.unsubscribe();
  }

  ngAfterViewInit() {
    setTimeout(() => this.reloadAll({ start: Date.now() - 3600 * 1000 * 24, end: Date.now() }, false), 0);
  }

  private onNotification(messages: PlatformMessage[]) {
    // lors de la réception de nouveaux messages, les groupe par type et mets les graphes à jour

    const data = messages.reduce((acc, cur) => {
      const type = (cur.type.toLowerCase() == "reading" ? (cur.data as ReadingMessage).type : cur.type).toLowerCase();

      (acc[type] || (acc[type] = [])).push(cur);

      return acc;
    }, {});

    if (data["usercommand"]) {
      this.commandData = [...this.commandData, ...data["usercommand"]];
    }

    if (data["temperature"]) {
      this.temperatureData = [...this.temperatureData, ...data["temperature"]];
    }

    if (data["humidity"]) {
      this.humidityData = [...this.humidityData, ...data["humidity"]];
    }

    if (data["presence"]) {
      this.presenceData = [...this.presenceData, ...data["presence"]];
    }
  }

  public async reloadAll(range: { start: number, end: number }, forceRenew: boolean = true) {
    this.commandChart.loading = true;
    this.presenceChart.loading = true;
    this.temperatureChart.loading = true;
    this.humidityChart.loading = true;

    const [readings, commands] = await Promise.all([
      this.readingSvc.get(range.start, range.end, forceRenew),
      this.commandSvc.get(range.start, range.end, forceRenew)]);
    this.temperatureData = readings.filter(m => (m.data as ReadingMessage).type.toLowerCase() == "temperature");
    this.humidityData = readings.filter(m => (m.data as ReadingMessage).type.toLowerCase()  == "humidity");
    this.presenceData = readings.filter(m => (m.data as ReadingMessage).type.toLowerCase()  == "presence");
    this.commandData = commands;

    this.commandChart.loading = false;
    this.presenceChart.loading = false;
    this.temperatureChart.loading = false;
    this.humidityChart.loading = false;
  }
}
