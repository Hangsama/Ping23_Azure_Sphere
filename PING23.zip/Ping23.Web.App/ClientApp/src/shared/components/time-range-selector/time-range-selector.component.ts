import { Component, Output, EventEmitter, Input, OnChanges, SimpleChanges } from "@angular/core";
import { FormGroup, FormControl } from "@angular/forms";
import { LocalizationService } from "../../services/localization.service";

@Component({
  selector: 'time-range-selector',
  templateUrl: './time-range-selector.component.html',
  styleUrls: ['./time-range-selector.component.css']
})
export class TimeRangeSelectorComponent {
  @Output() public rangeChange = new EventEmitter<{ start: number, end: number }>();

  public initialValue = new Date(Date.now() - 3600 * 1000 * 24).toISOString().slice(0, 16);
  public rangeType: string = "since";
  private start: number;
  private end: number;

  constructor(public readonly loc: LocalizationService) { }

  public changeType(value: string) {
    this.rangeType = value;
    this.onRangeChanged();
  }

  private onRangeChanged() {
    if (this.rangeType == "since") {
      this.end = Date.now();
      if (this.start == undefined) this.start = Date.now() - 1000 * 3600 * 24;
    }
    if (this.rangeType == "until") {
      this.start = 0;
      if (this.end == undefined) this.end = Date.now();
    }
    if (this.rangeType == "interval") {
      if (this.start == undefined) this.start = Date.now() - 1000 * 3600 * 24;
      if (this.end == undefined) this.end = Date.now();
    }
    if (this.rangeType == "alltime") {
      this.start = 0;
      this.end = Date.now();
    }

    this.rangeChange.emit({ start: this.start, end: this.end });
  }

  public setStart(iso: string) {
    this.start = new Date(iso).getTime();
    this.onRangeChanged();
  }

  public setEnd(iso: string) {
    this.end = new Date(iso).getTime();
    this.onRangeChanged();
  }
}
