import { ChartComponentBase } from "../chart.component";
import { Component, SimpleChanges } from "@angular/core";
import { LocalizationService } from "../../services/localization.service";
import { ReadingService } from "../../services/reading.service";
import { ReadingMessage } from "../../models/messages.model";

@Component({
  selector: 'temperature-chart',
  templateUrl: './temperature-chart.component.html',
  styleUrls: ['./temperature-chart.component.css']
})
export class TemperatureChartComponent extends ChartComponentBase {
  constructor(
    public readonly loc: LocalizationService,
    private readonly readingSvc: ReadingService) {
    super();
    this.chartColors = [{
      backgroundColor: 'rgba(192,0,0,0.2)',
      borderColor: 'rgba(192,0,0,1)',
      pointBackgroundColor: 'rgba(192,0,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(192,0,0,0.8)'
    }];
    this.chartOptions = {
      responsive: false,
      scales: {
        xAxes: [{
          type: 'linear',
          display: false
        }]
      },
      tooltips: {
        callbacks: {
          title: items => new Date(+items[0].xLabel).toLocaleString(this.loc.str("_locale"))
        }
      }
    };
  }

  ngOnChanges(changes: SimpleChanges) {
    if (!changes["data"]) return;

    // créer les valeurs de l'axe des ordonnées
    this.chartData = [{
      label: this.loc.str("chart_temperature"),
      data: this.data.map(m => ({ x: m.timestamp, y: (m.data as ReadingMessage).value }))
    }];
    // créer les valeurs de l'axe des abscisses 
    this.chartLabels = this.data.map(m => new Date(m.timestamp).toLocaleString(this.loc.str("_locale")));
  }
}
