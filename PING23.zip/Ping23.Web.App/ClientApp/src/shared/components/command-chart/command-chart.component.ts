import { ChartComponentBase } from "../chart.component";
import { Component, SimpleChanges } from "@angular/core";
import { LocalizationService } from "../../services/localization.service";
import { ReadingService } from "../../services/reading.service";
import { ReadingMessage } from "../..";

@Component({
  selector: 'command-chart',
  templateUrl: './command-chart.component.html',
  styleUrls: ['./command-chart.component.css']
})
export class CommandChartComponent extends ChartComponentBase {
  constructor(
    public readonly loc: LocalizationService,
    private readonly readingSvc: ReadingService) {
    super();
    this.chartColors = [{
      backgroundColor: 'rgba(0,192,0,0.2)',
      borderColor: 'rgba(0,192,0,1)',
      pointBackgroundColor: 'rgba(0,192,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,192,0,0.8)'
    }];
    this.chartOptions = {
      responsive: false,
      scaleShowVerticalLines: false,
      scales: {
        xAxes: [{
          display: false
        }]
      },
      tooltips: {
        callbacks: {
          title: items => new Date(+items[0].xLabel).toLocaleString(this.loc.str("_locale"))
        }
      }
    };
  }

  ngOnChanges(changes: SimpleChanges) {
    if (!changes["data"]) return;

    // récupère le nombre de commandes par intervalle de temps
    const data = this.data.reduce((acc, cur) => {
      const key = new Date(cur.timestamp).setSeconds(0);

      acc[key] = (acc[key] | 0) + 1

      return acc;
    }, {});

    // créer les valeurs de l'axe des ordonnées
    this.chartData = [{
      label: this.loc.str("chart_command"),
      data: Object.values(data)
    }];

    // créer les valeurs de l'axe des abscisses 
    this.chartLabels = Object.keys(data).map(t => +t);
  }
}
