import { ChartComponentBase } from "../chart.component";
import { Component, SimpleChanges } from "@angular/core";
import { LocalizationService } from "../../services/localization.service";
import { ReadingService } from "../../services/reading.service";
import { ReadingMessage } from "../..";

@Component({
  selector: 'humidity-chart',
  templateUrl: './humidity-chart.component.html',
  styleUrls: ['./humidity-chart.component.css']
})
export class HumidityChartComponent extends ChartComponentBase {
  constructor(
    public readonly loc: LocalizationService,
    private readonly readingSvc: ReadingService) {
    super();
    this.chartColors = [{
      backgroundColor: 'rgba(0,0,192,0.2)',
      borderColor: 'rgba(0,0,192,1)',
      pointBackgroundColor: 'rgba(0,0,192,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,0,192,0.8)'
    }];
    this.chartOptions = {
      responsive: false,
      scales: {
        xAxes: [{
          type: 'linear',
          display: false
        }]
      },
      tooltips: {
        callbacks: {
          title: items => new Date(+items[0].xLabel).toLocaleString(this.loc.str("_locale"))
        }
      }
    };
  }

  ngOnChanges(changes: SimpleChanges) {
    if (!changes["data"]) return;

    // créer les valeurs de l'axe des ordonnées
    this.chartData = [{
      label: this.loc.str("chart_humidity"),
      data: this.data.map(m => ({ x: m.timestamp, y: (m.data as ReadingMessage).value }))
    }];
    // créer les valeurs de l'axe des abscisses 
    this.chartLabels = this.data.map(m => new Date(m.timestamp).toLocaleString(this.loc.str("_locale")));
  }
}
