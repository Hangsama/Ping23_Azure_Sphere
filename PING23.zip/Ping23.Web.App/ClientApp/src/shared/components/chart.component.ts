import { PlatformMessage } from "../models/messages.model";
import { Input, OnChanges, SimpleChanges } from "@angular/core";

// classe de base d'un graphe
export abstract class ChartComponentBase implements OnChanges {
  @Input() protected data: PlatformMessage[] = [];
  @Input() public loading = false;

  public chartData: any[] = [];
  public chartLabels: any[] = [];
  public chartOptions: any = {};
  public chartColors: any[] = [];

  abstract ngOnChanges(changes: SimpleChanges);
}
