export interface Device {
  id: string;
  lastActivityTime: number;
  connectionState: string;
  connectionStateUpdatedTime: number;
  status: string;
  statusReason: string;
  statusUpdatedTime: number;
}
