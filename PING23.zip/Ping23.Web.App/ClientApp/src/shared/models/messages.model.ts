export interface PlatformMessage {
  type: string;
  origin: string;
  timestamp: number;
  data: ReadingMessage | string;
}

export interface ReadingMessage {
  type: string;
  value?: number;
}

export interface CloudCommandMessage {
  type: string;
  value?: number;
}
