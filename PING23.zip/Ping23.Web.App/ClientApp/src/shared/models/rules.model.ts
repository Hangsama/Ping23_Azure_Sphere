export interface Condition {
  key: string;
  value: any;
}

export interface Action {
  key: string;
  value: any;
}

export interface Rule {
  id: string;
  name: string;
  conditions: Condition[];
  actions: Action[];
}
