import { Injectable } from "@angular/core";
import { HubConnectionBuilder, HubConnection } from "@aspnet/signalr";
import { PlatformMessage } from "../models/messages.model";
import { Subject } from "rxjs/Subject";

@Injectable()
export class NotificationService {
  private readonly connection: HubConnection;
  public readonly onNotification: Subject<PlatformMessage[]>;

  constructor() {
    this.connection = new HubConnectionBuilder().withUrl("/hubs/notifications").build();
    this.onNotification = new Subject<PlatformMessage[]>();

    this.connection.on("notify", messages => this.onNotification.next(messages));
  }

  public start() {
    this.connection.start();
  }
}
