import { Injectable } from "@angular/core";
import { Http, Headers } from "@angular/http";
import { PlatformMessage } from "../models/messages.model";

@Injectable()
export class CommandService {
  constructor(private readonly http: Http) { }

  public async get(startTimestamp: number, endTimestamp: number, forceRenew: boolean = false): Promise<PlatformMessage[]> {
    const response = await this.http.get(`/api/Command?startTimestamp=${startTimestamp}&endTimestamp=${endTimestamp}&forceRenew=${forceRenew}`).toPromise();

    try { return response.json(); }
    catch (e) { return []; }
  }

  public async sendCommand(message: PlatformMessage): Promise<boolean> {
    const response = await this.http.post("/api/Command/_sendCommand", message).toPromise();

    return response.ok;
  }

  public async sendMessage(message: string): Promise<boolean> {
    const response = await this.http.get("/api/Command/_sendMessage?message=" + message).toPromise();

    return response.ok;
  }
}
