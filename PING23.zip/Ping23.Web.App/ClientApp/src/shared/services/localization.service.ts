import * as french from "../lang/french.json";
import * as english from "../lang/english.json";
import { Injectable } from "@angular/core";
import { Subject } from "rxjs/Subject";

@Injectable()
export class LocalizationService {
  private readonly languageNames = {
    "french": french,
    "english": english
  }
  private currentLanguage = english;

  public readonly onLanguageChange = new Subject<string>();

  public set language(value: string) {
    this.currentLanguage = this.languageNames[value] || english;

    this.onLanguageChange.next(Object.keys(this.languageNames).includes(value) ? value : "english");
  }

  public str(key: string, ...args: string[]) {
    // récupère une chaine du dictionaire et remplace les éventuels paramètres

    const value = this.currentLanguage[key] || key;

    for (let i = 0; i < args.length; i++)
      value.replace(`{${i}}`, args[i]);

    return value;
  }
}
