import { Injectable } from "@angular/core";
import { Http } from "@angular/http";
import { Device } from "../models/device.model";

@Injectable()
export class DeviceService {
  constructor(private readonly http: Http) { }

  public async getAll(): Promise<Device[]> {
    const response = await this.http.get("/api/Device").toPromise();

    try { return response.json(); }
    catch (e) { return []; }
  }
}
