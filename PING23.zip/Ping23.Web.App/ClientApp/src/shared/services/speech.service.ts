import { Injectable } from "@angular/core";
import { LocalizationService } from "./localization.service";
import { Subject } from "rxjs/Subject";

const SpeechRecognition = window["SpeechRecognition"] || window["webkitSpeechRecognition"];
const SpeechGrammarList = window["SpeechGrammarList"] || window["webkitSpeechGrammarList"];

@Injectable()
export class SpeechService {
  private recognition: any;
  public readonly onRecognition: Subject<string>;

  constructor(private readonly loc: LocalizationService) {
    loc.onLanguageChange.subscribe(() => this.initialize());
    this.onRecognition = new Subject<string>();
    this.initialize();
  }

  private initialize() {
    // initialise la grammaire à partir du JSGF de la locale actuelle

    const grammar = this.loc.str("_grammar");
    const speechRecognitionList = new SpeechGrammarList();

    speechRecognitionList.addFromString(grammar, 1);

    this.recognition = new SpeechRecognition();
    this.recognition.grammars = speechRecognitionList;
    this.recognition.lang = this.loc.str("_locale");
    this.recognition.interimResults = false;
    this.recognition.maxAlternatives = 1;
    this.recognition.onspeechend = () => this.recognition.stop();
    // déclenche l'évènement lorsqu'une phrase est reconnue
    this.recognition.onresult = event => this.onRecognition.next(event.results[event.results.length - 1][0].transcript);
  }

  public start() {
    this.recognition.start();
  }

  public stop() {
    this.recognition.stop();
  }
}
