import { Injectable } from "@angular/core";
import { Http } from "@angular/http";
import { PlatformMessage } from "../models/messages.model";
import { Rule } from "../models/rules.model";

@Injectable()
export class RuleService {
  constructor(private readonly http: Http) { }

  public async getAll(forceRenew: boolean = false): Promise<Rule[]> {
    const response = await this.http.get(`/api/Rule?forceRenew=${forceRenew}`).toPromise();

    try { return response.json(); }
    catch (e) { return []; }
  }

  public async get(id: string, forceRenew: boolean = false): Promise<Rule> {
    const response = await this.http.get(`/api/Rule/${id}?forceRenew=${forceRenew}`).toPromise();

    try { return response.json(); }
    catch (e) { return null; }
  }

  public async create(rule: Rule): Promise<string> {
    const response = await this.http.post("/api/Rule", rule).toPromise();

    try { return response.text(); }
    catch (e) { return null; }
  }

  public async update(rule: Rule): Promise<boolean> {
    const response = await this.http.put("/api/Rule", rule).toPromise();

    try { return response.text().toLowerCase() == "true"; }
    catch (e) { return null; }
  }

  public async delete(id: string): Promise<boolean> {
    const response = await this.http.delete(`/api/Rule/${id}`).toPromise();

    try { return response.text().toLowerCase() == "true"; }
    catch (e) { return null; }
  }
}
