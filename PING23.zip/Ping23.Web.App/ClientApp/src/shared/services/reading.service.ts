import { Injectable } from "@angular/core";
import { Http } from "@angular/http";
import { PlatformMessage } from "../models/messages.model";

@Injectable()
export class ReadingService {
  constructor(private readonly http: Http) { }

  public async get(startTimestamp: number, endTimestamp: number, forceRenew: boolean = false, ...types: string[]): Promise<PlatformMessage[]> {
    const typesQuery = types.length == 0 ? "" : ("&types=" + types.concat(","));
    const response = await this.http.get(`/api/Reading?startTimestamp=${startTimestamp}&endTimestamp=${endTimestamp}&forceRenew=${forceRenew}${typesQuery}`).toPromise();

    try { return response.json(); }
    catch (e) { return []; }
  }
}
