import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { ChartsModule } from 'ng2-charts';
import { CommandService } from './services/command.service';
import { DeviceService } from './services/device.service';
import { LocalizationService } from './services/localization.service';
import { NotificationService } from './services/notification.service';
import { ReadingService } from './services/reading.service';
import { SpeechService } from './services/speech.service';
import { CommandChartComponent } from './components/command-chart/command-chart.component';
import { HumidityChartComponent } from './components/humidity-chart/humidity-chart.component';
import { PresenceChartComponent } from './components/presence-chart/presence-chart.component';
import { TemperatureChartComponent } from './components/temperature-chart/temperature-chart.component';
import { TimeRangeSelectorComponent } from './components/time-range-selector/time-range-selector.component';
import { RuleService } from './services/rule.service';

@NgModule({
  declarations: [
    CommandChartComponent,
    HumidityChartComponent,
    PresenceChartComponent,
    TemperatureChartComponent,
    TimeRangeSelectorComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    HttpModule,
    FormsModule,
    ChartsModule
  ],
  exports: [
    CommandChartComponent,
    HumidityChartComponent,
    PresenceChartComponent,
    TemperatureChartComponent,
    TimeRangeSelectorComponent
  ],
  providers: [
    CommandService,
    DeviceService,
    LocalizationService,
    NotificationService,
    ReadingService,
    SpeechService,
    RuleService
  ],
})
export class SharedModule { }
