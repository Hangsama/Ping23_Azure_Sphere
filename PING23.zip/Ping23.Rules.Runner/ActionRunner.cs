﻿using Microsoft.Azure.Devices;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Ping23.Common.DTO.Rules;
using Ping23.Common.Model;
using Ping23.Common.Model.Misc;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ping23.Rules.Runner
{
    public class ActionRunner
    {
        private readonly IoTHubSettings _iotHubSettings;
        private readonly ILogger<ActionRunner> _logger;
        private bool _isInitialized = false;
        private ServiceClient _client;
        private string[] _deviceIds;

        public ActionRunner(IoTHubSettings iotHubSettings, ILogger<ActionRunner> logger)
        {
            _iotHubSettings = iotHubSettings;
            _logger = logger;
        }

        // exécute une action de règle
        public async Task Run(Common.DTO.Rules.Action action)
        {
            if (!_isInitialized) await Initialize();

            // créer le PlatformMessage à partir de 'laction
            var platformMessage = CreateMessage(action);

            if (platformMessage == null)
            {
                _logger.LogWarning("Invalid action: " + action.Key);

                return;
            }

            await Send(action);
        }

        public async Task Send<T>(T obj)
        {
            // convertir le message en message IoT Hub
            var json = JsonConvert.SerializeObject(obj);
            var bytes = Encoding.UTF8.GetBytes(json);
            var iotHubMessage = new Message(bytes);

            // envoyer le message à tous les devices connectés
            await Task.WhenAll(_deviceIds.Select(id => _client.SendAsync(id, iotHubMessage)));
        }
        
        // crée la connection à IoT Hub et récupère la liste des devices pour broadcast
        private async Task Initialize()
        {
            var registryManager = RegistryManager.CreateFromConnectionString(_iotHubSettings.ConnectionString);
#pragma warning disable CS0618
            var devices = await registryManager.GetDevicesAsync(int.MaxValue);
#pragma warning restore CS0618

            _client = ServiceClient.CreateFromConnectionString(_iotHubSettings.ConnectionString);
            _deviceIds = devices
                .Where(x => x.Status == DeviceStatus.Enabled && x.ConnectionState == DeviceConnectionState.Connected)
                .Select(device => device.Id)
                .ToArray();

            _isInitialized = true;
        }

        // traduit l'action en message
        private static PlatformMessage CreateMessage(Common.DTO.Rules.Action action)
        {
            PlatformMessage<T> createMessage<T>(string type, T data) => new PlatformMessage<T>
            {
                Type = type,
                Origin = "Rules",
                Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                Data = data
            };

            switch (action.Key)
            {
                case ActionType.SetLight:
                case ActionType.SetAlarm:
                case ActionType.SetDoor:
                case ActionType.SetThermostatValue:
                    if (action is Common.DTO.Rules.Action<double> doubleAction)
                        return createMessage(MessageType.CloudCommand.ToString(), new CloudCommand
                        {
                            Type = action.Key.ToString(),
                            Value = doubleAction.Value
                        });
                    else goto default;
                case ActionType.SendMessage when action is Common.DTO.Rules.Action<string> stringAction:
                    return createMessage(MessageType.CloudMessage.ToString(), stringAction.Value);
                default: return null;
            }
        }
    }
}
