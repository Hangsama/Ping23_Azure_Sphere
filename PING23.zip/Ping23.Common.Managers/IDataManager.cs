﻿using Ping23.Common.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Ping23.Common.Managers
{
    public interface IMessageManager<TData>
    {
        Task<IEnumerable<PlatformMessage<TData>>> Get(long startTimestamp, long endTimestamp, bool forceRenew = false);
    }
}
