﻿using Ping23.Common.DTO.Rules;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Ping23.Common.Managers
{
    public interface IRuleManager
    {
        Task<IEnumerable<Rule>> GetAll(bool forceRenew = false);
        Task<Rule> Get(string id, bool forceRenew = false);
        Task<string> Create(Rule rule, bool forceRenew = false);
        Task<bool> Update(Rule rule, bool forceRenew = false);
        Task<bool> Delete(string id, bool forceRenew = false);
    }
}
