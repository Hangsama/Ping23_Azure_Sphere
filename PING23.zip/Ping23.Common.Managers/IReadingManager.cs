﻿using Ping23.Common.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Ping23.Common.Managers
{
    public interface IReadingManager : IMessageManager<ReadingMessage>
    {
        Task<IEnumerable<PlatformMessage<ReadingMessage>>> Get(long startTimestamp, long endTimestamp, IEnumerable<string> types, bool forceRenew = false);
    }
}
