﻿namespace Ping23.Common.Managers
{
    public interface ICommandManager : IMessageManager<string> { }
}
