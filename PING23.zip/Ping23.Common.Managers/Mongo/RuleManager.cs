﻿using System.Collections.Generic;
using System.Threading.Tasks;
using MongoDB.Driver;
using Ping23.Common.Providers.MongoDB;
using StackExchange.Redis;
using Ping23.Common.DTO.Rules;
using Ping23.Common.Model.Misc;
using System.Linq;
using MongoDB.Bson;
using System.IO;
using MongoDB.Bson.IO;
using MongoDB.Bson.Serialization;

namespace Ping23.Common.Managers.Mongo
{
    public class RuleManager : IRuleManager
    {
        private readonly MongoDbProvider _provider;
        private readonly IMongoCollection<Wrappers.Rule> _collection;
        private readonly IDatabase _cache;

        public RuleManager(MongoDbSettings settings, RedisSettings redisSettings)
        {
            _provider = new MongoDbProvider(settings);
            _collection = _provider.Database.GetCollection<Wrappers.Rule>("rules");
            _cache = ConnectionMultiplexer.Connect(redisSettings.ConnectionString).GetDatabase();
        }

        public async Task<IEnumerable<Rule>> GetAll(bool forceRenew = false)
        {
            //On crée une clé permettant de récupérer les règles contenues en cache
            var key = "rules";

            //Si on utilise le cache
            if (!forceRenew)
            {
                // On récupère les informations souhaitées à partir du cache en utilisant la clé précedemment créee
                var cached = await GetCache<Wrappers.Rule[]>(key);

                //Si la récupération a réussi, on retourne la collection de Rule
                if (cached != null) return cached.Select(x => (Rule)x).ToArray();
            }

            /*Si on force la récupération des données depuis MongoDB ou que les informations n'existent pas en cache, on effectue une requête en base
             avec un filtre empty car nous souhaitons récupérer toutes les règles*/
            var cursor = await _collection.FindAsync(FilterDefinition<Wrappers.Rule>.Empty);

            //On effectue la requête et on obtient les résultats dans une collection
            var result = await cursor.ToListAsync();

            //On met le résultat en cache à l'aide de la clé précedemment créee, le résultat reste en cache indéfiniment
            await _cache.StringSetAsync(key, Serialize(result));

            // On retourne la collection de Rule
            return result.Select(x => (Rule)x).ToArray();
        }

        public async Task<Rule> Get(string id, bool forceRenew = false)
        {
            //On crée une clé unique permettant de récupérer une règle contenue en cache
            var key = "rules," + id;

            //Si on utilise le cache
            if (!forceRenew)
            {
                // On récupère les informations souhaitées à partir du cache en utilisant la clé précedemment créee
                var cached = await GetCache<Wrappers.Rule>(key);

                //Si la récupération a réussi, on retourne la règle
                if (cached != null) return (Rule)cached;
            }

            //Si on force la récupération des données depuis MongoDB ou que les informations n'existent pas en cache, on effectue une requête en base
            var cursor = await _collection.FindAsync(Builders<Wrappers.Rule>.Filter.Eq(rule => rule.Id, new ObjectId(id)));

            //On effectue la requête et on obtient la règle en certifiant qu'elle est unique (throw si plusieurs règles ont le même ID)
            var result = await cursor.SingleOrDefaultAsync();

            //On met le résultat en cache à l'aide de la clé précedemment créee
            await _cache.StringSetAsync(key, Serialize(result));

            //On retourne la règle
            return (Rule)result;
        }

        public async Task<string> Create(Rule rule, bool forceRenew = false)
        {
            var document = (Wrappers.Rule)rule;

            //On insère la règle en base, on set le cache avec la nouvelle valeur
            await Task.WhenAll(_collection.InsertOneAsync(document),
                               _cache.StringSetAsync("rules", RedisValue.Null),
                               _cache.StringSetAsync("rules," + document.Id.ToString(), Serialize(document)));

            //On retourne l'Id du la règle créee
            return document.Id.ToString();
        }

        public async Task<bool> Update(Rule rule, bool forceRenew = false)
        {
            var document = (Wrappers.Rule)rule;

            //On met à jour la règle en base
            var result = await _collection.ReplaceOneAsync(Builders<Wrappers.Rule>.Filter.Eq(r => r.Id, document.Id), document);

            //On set le cache avec la nouvelle valeur
            await Task.WhenAll(
                _cache.StringSetAsync("rules", RedisValue.Null),
                _cache.StringSetAsync("rules," + rule.Id, Serialize(document)));

            return result.IsAcknowledged && result.ModifiedCount > 0;
        }

        public async Task<bool> Delete(string id, bool forceRenew = false)
        {
            //On efface la règle en base
            var result = await _collection.DeleteOneAsync(Builders<Wrappers.Rule>.Filter.Eq(r => r.Id, new ObjectId(id)));

            //On set le cache en retirant la valeur de la règle
            await Task.WhenAll(_cache.StringSetAsync("rules", RedisValue.Null), _cache.StringSetAsync("rules," + id, RedisValue.Null));

            return result.IsAcknowledged && result.DeletedCount > 0;
        }

        private async Task<T> GetCache<T>(string key)
        {
            var redisValue = await _cache.StringGetAsync(key);

            if (!redisValue.IsNullOrEmpty)
            {
                var cached = Deserialize<T>(_cache.StringGet(key));

                if (cached != null) return cached;
            }

            return default(T);
        }

        private static byte[] Serialize(object value)
        {
            using (var stream = new MemoryStream())
            using (var writer = new BsonBinaryWriter(stream))
            {
                BsonSerializer.Serialize(writer, value.GetType(), value);

                return stream.ToArray();
            }
        }

        private static T Deserialize<T>(byte[] buffer)
        {
            using (var stream = new MemoryStream(buffer))
            using (var reader = new BsonBinaryReader(stream))            
                return (T)BsonSerializer.Deserialize(reader, typeof(T));            
        }
    }
}