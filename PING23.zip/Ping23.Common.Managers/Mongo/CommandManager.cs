﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MongoDB.Driver;
using Newtonsoft.Json;
using Ping23.Common.Model;
using Ping23.Common.Model.Misc;
using Ping23.Common.Providers.MongoDB;
using StackExchange.Redis;

namespace Ping23.Common.Managers.Mongo
{
    public class CommandManager : ICommandManager
    {
        private readonly MongoDbProvider _provider;
        private readonly IMongoCollection<Wrappers.PlatformMessage<string>> _collection;
        private readonly IDatabase _cache;

        public CommandManager(MongoDbSettings settings, RedisSettings redisSettings)
        {
            _provider = new MongoDbProvider(settings);
            _collection = _provider.Database.GetCollection<Wrappers.PlatformMessage<string>>("commands");
            _cache = ConnectionMultiplexer.Connect(redisSettings.ConnectionString).GetDatabase();
        }

        public async Task<IEnumerable<PlatformMessage<string>>> Get(long startTimestamp, long endTimestamp, bool forceRenew = false)
        {
            //On crée une clé unique permettant de stocker les données dans le cache
            string key = $"commands,{startTimestamp},{endTimestamp}"; 

            //On créer un filtre afin d'obtenir uniquement les données dans un interval de temps précis
            var filter = Builders<Wrappers.PlatformMessage<string>>
                        .Filter
                        .And(Builders<Wrappers.PlatformMessage<string>>.Filter.Gte(x => x.Timestamp, startTimestamp),
                             Builders<Wrappers.PlatformMessage<string>>.Filter.Lte(x => x.Timestamp, endTimestamp)
                         );

            //Si on utilise le cache
            if (!forceRenew)
            {
                //On récupère les données dans le cache à l'aide de la clé précedemment créee
                var redisValue = await _cache.StringGetAsync(key); 

                //Si les données existent dans le cache
                if (!redisValue.IsNullOrEmpty)
                {
                    //On déserialise le JSON en IEnumerable<PlatforMessage<string>>
                    var cached = JsonConvert.DeserializeObject<IEnumerable<Wrappers.PlatformMessage<string>>>(_cache.StringGet(key));

                    //Si la désérialisation a réussi, on retourne la collection de PlatformMessage 
                    if (cached != null) return cached;
                }
            }

            //Si on force la récupération des données depuis MongoDB ou que les informations n'existent pas en cache, on effectue une requête en base
            var cursor = await _collection.FindAsync(filter);

            //On effectue la requête et on obtient les résultats dans une collection
            var result = await cursor.ToListAsync();

            //On met le résultat en cache à l'aide de la clé précedemment créee, le résultat reste en cache pendant 5 minutes
            await _cache.StringSetAsync(key, JsonConvert.SerializeObject(result), expiry: new TimeSpan(0, 5, 0));

            // On retourne la collection de PlatformMessage
            return result;
        }
    }
}