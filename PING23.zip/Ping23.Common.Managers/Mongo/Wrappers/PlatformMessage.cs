﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Ping23.Common.Managers.Mongo.Wrappers
{
    internal class PlatformMessage<TData> : Model.PlatformMessage<TData>
    {
        [BsonId]
        public ObjectId Id { get; set; }
    }
}