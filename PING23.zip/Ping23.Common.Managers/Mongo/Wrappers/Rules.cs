﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Ping23.Common.Managers.Mongo.Wrappers
{
    internal class Rule
    {
        [BsonId]
        public ObjectId Id { get; set; }

        [BsonElement("name")]
        public string Name { get; set; }

        [BsonElement("conditions")]
        public IEnumerable<KeyValuePair> Conditions { get; set; }

        [BsonElement("actions")]
        public IEnumerable<KeyValuePair> Actions { get; set; }

        public static explicit operator DTO.Rules.Rule(Rule rule) => new DTO.Rules.Rule
        {
            Id = rule.Id.ToString(),
            Name = rule.Name,
            Conditions = rule.Conditions.Select(x => (DTO.Rules.Condition)x).ToArray(),
            Actions = rule.Actions.Select(x => (DTO.Rules.Action)x).ToArray()
        };

        public static explicit operator Rule(DTO.Rules.Rule rule) => new Rule
        {
            Id = rule.Id != null ? new ObjectId(rule.Id) : ObjectId.Empty,
            Name = rule.Name,
            Conditions = rule.Conditions.Select(x => (KeyValuePair)x).ToArray(),
            Actions = rule.Actions.Select(x => (KeyValuePair)x).ToArray()
        };
    }

    internal class KeyValuePair
    {
        [BsonElement("key")]
        public string Key { get; set; }

        [BsonElement("value")]
        public BsonValue Value { get; set; }

        public static explicit operator DTO.Rules.Condition(KeyValuePair pair)
        {
            var type = Enum.TryParse<DTO.Rules.ConditionType>(pair.Key, out var t) ? t : DTO.Rules.ConditionType.Unknown;

            try
            {
                switch (type)
                {
                    case DTO.Rules.ConditionType.ValueEq:
                    case DTO.Rules.ConditionType.ValueLt:
                    case DTO.Rules.ConditionType.ValueLte:
                    case DTO.Rules.ConditionType.ValueGt:
                    case DTO.Rules.ConditionType.ValueGte:
                        if( pair.Value["value"]?.IsNumeric == true)
                        return new DTO.Rules.Condition<DTO.Rules.ValueCondition<double>>
                        {
                            Key = type,
                            Value = JsonConvert.DeserializeObject<DTO.Rules.ValueCondition<double>>(pair.Value.ToJson())
                        };
                        else
                            return new DTO.Rules.Condition<DTO.Rules.ValueCondition<string>>
                            {
                                Key = type,
                                Value = JsonConvert.DeserializeObject<DTO.Rules.ValueCondition<string>>(pair.Value.ToJson())
                            };
                    case DTO.Rules.ConditionType.ValueMatches:
                        return new DTO.Rules.Condition<DTO.Rules.ValueCondition<string>>
                        {
                            Key = type,
                            Value = JsonConvert.DeserializeObject<DTO.Rules.ValueCondition<string>>(pair.Value.ToJson())
                        };
                    default: return new DTO.Rules.Condition { Key = type };
                }
            }
            catch
            {
                return new DTO.Rules.Condition { Key = type };
            }
        }

        public static explicit operator DTO.Rules.Action(KeyValuePair pair)
        {
            var type = Enum.TryParse<DTO.Rules.ActionType>(pair.Key, out var t) ? t : DTO.Rules.ActionType.Unknown;

            try
            {
                switch (type)
                {
                    case DTO.Rules.ActionType.SendMessage when pair.Value.IsString:
                        return new DTO.Rules.Action<string>
                        {
                            Key = type,
                            Value = pair.Value.ToString()
                        };
                    case DTO.Rules.ActionType.SetLight when pair.Value.IsNumeric:
                    case DTO.Rules.ActionType.SetAlarm when pair.Value.IsNumeric:
                    case DTO.Rules.ActionType.SetDoor when pair.Value.IsNumeric:
                    case DTO.Rules.ActionType.SetThermostatValue when pair.Value.IsNumeric:
                        return new DTO.Rules.Action<double>
                        {
                            Key = type,
                            Value = pair.Value.ToDouble()
                        };
                    default: return new DTO.Rules.Action { Key = type };
                }
            }
            catch
            {
                return new DTO.Rules.Action { Key = type };
            }
        }

        public static explicit operator KeyValuePair(DTO.Rules.Condition condition) => new KeyValuePair
        {
            Key = condition.Key.ToString(),
            Value = condition.Value is JObject obj ? BsonDocument.Parse(obj.ToString()) : BsonValue.Create(condition.Value)
        };

        public static explicit operator KeyValuePair(DTO.Rules.Action action) => new KeyValuePair
        {
            Key = action.Key.ToString(),
            Value = action.Value is JObject obj ? BsonDocument.Parse(obj.ToString()) : BsonValue.Create(action.Value)
        };
    }

    internal class EquatableObject : IEquatable<EquatableObject>
    {
        public bool Equals(EquatableObject other) => base.Equals(other);
    }
}