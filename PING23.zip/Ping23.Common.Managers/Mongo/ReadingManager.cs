﻿using System.Collections.Generic;
using System.Threading.Tasks;
using MongoDB.Driver;
using Ping23.Common.Model;
using Ping23.Common.Providers.MongoDB;
using System.Linq;
using StackExchange.Redis;
using Newtonsoft.Json;
using System;
using Ping23.Common.Model.Misc;

namespace Ping23.Common.Managers.Mongo
{
    public class ReadingManager : IReadingManager
    {
        private readonly MongoDbProvider _provider;
        private readonly IMongoCollection<Wrappers.PlatformMessage<ReadingMessage>> _collection;
        private readonly IDatabase _cache;

        public ReadingManager(MongoDbSettings settings, RedisSettings redisSettings)
        {
            _provider = new MongoDbProvider(settings);
            _collection = _provider.Database.GetCollection<Wrappers.PlatformMessage<ReadingMessage>>("readings");
            _cache = ConnectionMultiplexer.Connect(redisSettings.ConnectionString).GetDatabase();
        }
        public async Task<IEnumerable<PlatformMessage<ReadingMessage>>> Get(long startTimestamp, long endTimestamp, IEnumerable<string> types, bool forceRenew = false)
        {
            //On crée une clé unique permettant de stocker les données dans le cache 
            string key = $"readings,{startTimestamp},{endTimestamp},{types.Aggregate((acc, curr) => $"{acc}:{curr}")}";

            //On créer un filtre afin d'obtenir uniquement les données dans un interval de temps et avec un ou plusieurs types précis
            var filter = Builders<Wrappers.PlatformMessage<ReadingMessage>>
                        .Filter
                        .And(Builders<Wrappers.PlatformMessage<ReadingMessage>>.Filter.Gte(x => x.Timestamp, startTimestamp),
                             Builders<Wrappers.PlatformMessage<ReadingMessage>>.Filter.Lte(x => x.Timestamp, endTimestamp),
                             Builders<Wrappers.PlatformMessage<ReadingMessage>>.Filter.Where(x => types.Contains(x.Type))
                         );

            //Si on utilise le cache
            if (!forceRenew)
            {
                //On récupère les informations souhaitées à partir du cache en utilisant la clé précedemment créee
                var cached = await GetCache(key);

                //Si la récupération a réussi, on retourne la collection de PlatformMessage
                if (cached != null) return cached;
            }

            //Si on force la récupération des données depuis MongoDB ou que les informations n'existent pas en cache, on effectue une requête en base
            var cursor = await _collection.FindAsync(filter);

            //On effectue la requête et on obtient les résultats dans une collection
            var result = await cursor.ToListAsync();

            //On met le résultat en cache à l'aide de la clé précedemment créee, le résultat reste en cache pendant 5 minutes
            await _cache.StringSetAsync(key, JsonConvert.SerializeObject(result.ToArray()), expiry: new TimeSpan(0, 5, 0));

            // On retourne la collection de PlatformMessage
            return result;
        }

        public async Task<IEnumerable<PlatformMessage<ReadingMessage>>> Get(long startTimestamp, long endTimestamp, bool forceRenew = false)
        {
            //On crée une clé unique permettant de stocker les données dans le cache 
            string key = $"readings,{startTimestamp},{endTimestamp}";

            //On créer un filtre afin d'obtenir uniquement les données dans un interval de temps précis
            var filter = Builders<Wrappers.PlatformMessage<ReadingMessage>>
                        .Filter
                        .And(Builders<Wrappers.PlatformMessage<ReadingMessage>>.Filter.Gte(x => x.Timestamp, startTimestamp),
                             Builders<Wrappers.PlatformMessage<ReadingMessage>>.Filter.Lte(x => x.Timestamp, endTimestamp)
                         );

            //Si on utilise le cache
            if (!forceRenew)
            {
                //On récupère les informations souhaitées à partir du cache en utilisant la clé précedemment créee
                var cached = await GetCache(key);

                //Si la récupération a réussi, on retourne la collection de PlatformMessage
                if (cached != null) return cached;
            }

            //Si on force la récupération des données depuis MongoDB ou que les informations n'existent pas en cache, on effectue une requête en base
            var cursor = await _collection.FindAsync(filter);

            //On effectue la requête et on obtient les résultats dans une collection
            var result = await cursor.ToListAsync();

            //On met le résultat en cache à l'aide de la clé précedemment créee, le résultat reste en cache pendant 5 minutes
            await _cache.StringSetAsync(key, JsonConvert.SerializeObject(result.ToArray()), expiry: new TimeSpan(0, 5, 0));

            return result;
        }

        private async Task<PlatformMessage<ReadingMessage>[]> GetCache(string key)
        {
            //On récupère les données dans le cache à l'aide de la clé précedemment créee
            var redisValue = await _cache.StringGetAsync(key);

            //Si les données existent dans le cache
            if (!redisValue.IsNullOrEmpty)
            {
                //On déserialise le JSON en IEnumerable<PlatforMessage<ReadingMessage[]>>
                var cached = JsonConvert.DeserializeObject<Wrappers.PlatformMessage<ReadingMessage>[]>(_cache.StringGet(key));

                //Si la désérialisation a réussi, on retourne la collection de PlatformMessage 
                if (cached != null) return cached;
            }
            //Sinon on retoune null
            return null;
        }
    }
}