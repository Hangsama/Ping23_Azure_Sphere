﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;

namespace Ping23.Common.DTO.Rules
{
    public enum ActionType
    {
        Unknown, SendMessage, SetLight, SetAlarm, SetDoor, SetThermostatValue
    }

    public class Action : IEquatable<Action>
    {
        [JsonConverter(typeof(StringEnumConverter))]
        public ActionType Key { get; set; }
        public object Value { get; set; }

        public bool Equals(Action other) => other?.GetType() == GetType() && Key.Equals(other.Key);

        public override bool Equals(object obj) => obj is Action other && Equals(other);

        public override int GetHashCode() => Value != null ? Key.GetHashCode() ^ Value.GetHashCode() : Key.GetHashCode();
    }

    public class Action<TData> : Action, IEquatable<Action<TData>>
        where TData : IEquatable<TData>
    {
        new public TData Value { get; set; }

        public bool Equals(Action<TData> other) => base.Equals(other) && (Value == null && other.Value == null || Value.Equals(other.Value));

        public override bool Equals(object obj) => obj is Action<TData> other && Equals(other);

        public override int GetHashCode() => Value != null ? Key.GetHashCode() ^ Value.GetHashCode() : Key.GetHashCode();
    }
}
