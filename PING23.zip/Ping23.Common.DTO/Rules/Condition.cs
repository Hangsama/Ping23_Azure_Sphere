﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;

namespace Ping23.Common.DTO.Rules
{
    public enum ConditionType
    {
        Unknown, ValueEq, ValueLt, ValueLte, ValueGt, ValueGte, ValueMatches
    }

    public class Condition : IEquatable<Condition>
    {
        [JsonConverter(typeof(StringEnumConverter))]
        public ConditionType Key { get; set; }
        public object Value { get; set; }

        public bool Equals(Condition other) => other?.GetType() == GetType() && Key.Equals(other.Key);

        public override bool Equals(object obj) => obj is Condition other && Equals(other);

        public override int GetHashCode() => Value != null ? Key.GetHashCode() ^ Value.GetHashCode() : Key.GetHashCode();
    }

    public class Condition<TData> : Condition, IEquatable<Condition<TData>>
        where TData : IEquatable<TData>
    {
        new public TData Value { get; set; }

        public bool Equals(Condition<TData> other) => base.Equals(other) && (Value == null && other.Value == null || Value.Equals(other.Value));

        public override bool Equals(object obj) => obj is Condition<TData> other && Equals(other);

        public override int GetHashCode() => Value != null ? Key.GetHashCode() ^ Value.GetHashCode() : Key.GetHashCode();
    }

    public class ValueCondition<T> : IEquatable<ValueCondition<T>>
    {
        public string Key { get; set; }
        public T Value { get; set; }

        public bool Equals(ValueCondition<T> other) => Key == other?.Key && (Value == null && other.Value == null || Value.Equals(other.Value));

        public override bool Equals(object obj) => obj is ValueCondition<T> other && Equals(other);

        public override int GetHashCode() => Value != null ? Key.GetHashCode() ^ Value.GetHashCode() : Key.GetHashCode();
    }
}
