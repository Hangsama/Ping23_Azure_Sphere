﻿using System.Collections.Generic;

namespace Ping23.Common.DTO.Rules
{
    public class Rule
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public IEnumerable<Condition> Conditions { get; set; }
        public IEnumerable<Action> Actions { get; set; }
    }
}
