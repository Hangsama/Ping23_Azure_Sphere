﻿using Microsoft.Azure.EventHubs.Processor;
using Microsoft.Extensions.DependencyInjection;

namespace Ping23.Rules.Service.Services
{
    public class EventHubListenerFactory : IEventProcessorFactory
    {
        private readonly IServiceScopeFactory _scopeFactory;

        public EventHubListenerFactory(IServiceScopeFactory scopeFactory)
        {
            _scopeFactory = scopeFactory;
        }

        public IEventProcessor CreateEventProcessor(PartitionContext context)
        {
            using (var scope = _scopeFactory.CreateScope())
                return scope.ServiceProvider.GetService<EventHubListener>();
        }
    }
}
