﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.EventHubs;
using Microsoft.Azure.EventHubs.Processor;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Ping23.Common.Managers;
using Ping23.Common.Utils;
using Ping23.Rules.Engine;

namespace Ping23.Rules.Service.Services
{
    public class EventHubListener : IEventProcessor
    {
        private readonly IRuleManager _ruleManager;
        private readonly MessageSender _sender;
        private readonly ILogger<EventHubListener> _logger;

        public EventHubListener(IRuleManager ruleManager, MessageSender _sender, ILogger<EventHubListener> logger)
        {
            _ruleManager = ruleManager;
            this._sender = _sender;
            _logger = logger;
        }

        public async Task ProcessEventsAsync(PartitionContext context, IEnumerable<EventData> messages)
        {
            // à la réception de messages de IoT Hub
            // instantie le moteur de règles à partir des règles présentes en base
            // et exécute l'ensemble des actions trouvées
            
            _logger.LogInformation($"Received {messages.Count()} messages from IoT Hub.");

            try
            {
                var tokens = messages.Select(m => m.Body.ToArray()).Select(Encoding.UTF8.GetString).Select(JToken.Parse).ToList();
                var rules = await _ruleManager.GetAll();
                var engine = new RuleEngine(rules);
                var actions = tokens.SelectMany(engine.Feed).ToArray();

                await Task.WhenAll(actions.Select(_sender.Run));
            }
            catch(Exception e)
            {
                _logger.LogError(e.Message);
            }
        }

        public Task CloseAsync(PartitionContext context, CloseReason reason) => Task.CompletedTask;

        public Task OpenAsync(PartitionContext context) => Task.CompletedTask;

        public Task ProcessErrorAsync(PartitionContext context, Exception error)
        {
            _logger.LogError(error.Message);

            return Task.CompletedTask;
        }
    }
}
