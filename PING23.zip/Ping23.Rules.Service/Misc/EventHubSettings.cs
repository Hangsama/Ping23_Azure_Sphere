﻿namespace Ping23.Rules.Service.Misc
{
    public class EventHubSettings
    {
        public string ConnectionString { get; set; }
        public string Name { get; set; }
        public string ConsumerGroup { get; set; }
        public string StorageConnectionString { get; set; }
        public string StorageContainerName { get; set; }
    }
}
