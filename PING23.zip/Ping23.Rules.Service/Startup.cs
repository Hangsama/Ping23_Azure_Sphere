﻿using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Azure.EventHubs.Processor;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Ping23.Common.Managers;
using Ping23.Common.Managers.Mongo;
using Ping23.Common.Model.Misc;
using Ping23.Common.Providers.MongoDB;
using Ping23.Common.Utils;
using Ping23.Rules.Service.Misc;
using Ping23.Rules.Service.Services;

namespace Ping23.Rules.Service
{
    public class Startup
    {
        public readonly IConfiguration Configuration;

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            var eventHubSettings = Configuration.GetSection(nameof(EventHubSettings)).Get<EventHubSettings>();
            var mongoDbSettings = Configuration.GetSection(nameof(MongoDbSettings)).Get<MongoDbSettings>();
            var iotHubSettings = Configuration.GetSection(nameof(IoTHubSettings)).Get<IoTHubSettings>();
            var redisSettings = Configuration.GetSection(nameof(RedisSettings)).Get<RedisSettings>();

            services.AddSingleton(eventHubSettings);
            services.AddSingleton(mongoDbSettings);
            services.AddSingleton(iotHubSettings);
            services.AddSingleton(redisSettings);

            services.AddLogging();

            services.AddScoped<MongoDbProvider>();
            services.AddScoped<IRuleManager, RuleManager>();

            services.AddSingleton<MessageSender>();
            services.AddScoped<EventHubListener>();
            services.AddSingleton<EventHubListenerFactory>();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env, IApplicationLifetime lifetime,
            EventHubListenerFactory eventHubListenerFactory, EventHubSettings eventHubSettings)
        {
            if (env.IsDevelopment())            
                app.UseDeveloperExceptionPage();

            ConfigureEventHubListener(lifetime, eventHubListenerFactory, eventHubSettings);

            app.Run(context =>
            {
                context.Response.StatusCode = (int)HttpStatusCode.Forbidden;

                return Task.CompletedTask;
            });
        }

        private void ConfigureEventHubListener(IApplicationLifetime lifetime, EventHubListenerFactory eventHubListenerFactory, EventHubSettings eventHubSettings)
        {
            var eventProcessorHost = new EventProcessorHost(
                eventHubSettings.Name,
                eventHubSettings.ConsumerGroup,
                eventHubSettings.ConnectionString,
                eventHubSettings.StorageConnectionString,
                eventHubSettings.StorageContainerName);

            eventProcessorHost.RegisterEventProcessorFactoryAsync(eventHubListenerFactory).Wait();

            lifetime.ApplicationStopped.Register(() => eventProcessorHost.UnregisterEventProcessorAsync().Wait());
        }
    }
}
