﻿using Newtonsoft.Json.Linq;
using Ping23.Common.DTO.Rules;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Ping23.Rules.Engine
{
    public class RuleEngine
    {
        private readonly IEnumerable<Node> _treeRoot;

        public RuleEngine(IEnumerable<Rule> rules)
        {
            _treeRoot = TreeHelper.Build(rules);
        }

        // passe un message dans l'arbre de décision et retourne les actions trouvées
        public IEnumerable<Action> Feed(JToken message)
        {
            // ajoute tous les noeuds à la racine à la queue
            var queue = new Queue<Node>(_treeRoot);

            while (queue.Count > 0)
            {
                var node = queue.Dequeue();

                switch (node.Value)
                {
                    // si le noeud est une feuille, retourne les actions
                    case IEnumerable<Action> actions:
                        foreach (var action in actions)
                            yield return action;
                        break;
                    // si le noeud est une branche, teste la condition et ajoute les enfants a la queue si elle est validée
                    case Condition condition when Test(message, condition):
                        node.Next.ForEach(queue.Enqueue);
                        break;
                }
            }
        }

        private bool Test(JToken message, Condition condition)
        {
            switch (condition.Key)
            {
                case ConditionType.ValueEq when condition is Condition<ValueCondition<string>> valueCondition:
                    return (message
                        .SelectToken(valueCondition.Value.Key)?.ToObject(valueCondition.Value.Value.GetType()))
                        ?.Equals(valueCondition.Value.Value) == true;

                case ConditionType.ValueEq when condition is Condition<ValueCondition<double>> valueCondition:
                    return (message
                        .SelectToken(valueCondition.Value.Key)?.ToObject(valueCondition.Value.Value.GetType()))
                        ?.Equals(valueCondition.Value.Value) == true;

                case ConditionType.ValueLt when condition is Condition<ValueCondition<double>> valueCondition:
                    return (message
                        .SelectToken(valueCondition.Value.Key)?.ToObject<double>())
                        ?.CompareTo(valueCondition.Value.Value) < 0;

                case ConditionType.ValueLte when condition is Condition<ValueCondition<double>> valueCondition:
                    return (message
                        .SelectToken(valueCondition.Value.Key)?.ToObject<double>())
                        ?.CompareTo(valueCondition.Value.Value) <= 0;

                case ConditionType.ValueGt when condition is Condition<ValueCondition<double>> valueCondition:
                    return (message
                        .SelectToken(valueCondition.Value.Key)?.ToObject<double>())
                        ?.CompareTo(valueCondition.Value.Value) > 0;

                case ConditionType.ValueGte when condition is Condition<ValueCondition<double>> valueCondition:
                    return (message
                        .SelectToken(valueCondition.Value.Key)?.ToObject<double>())
                        ?.CompareTo(valueCondition.Value.Value) >= 0;

                case ConditionType.ValueMatches when condition is Condition<ValueCondition<string>> valueCondition:
                    return Regex.Match(
                            message.SelectToken(valueCondition.Value.Key)?.ToObject<string>(),
                            valueCondition.Value.Value)
                        .Success;

                default: return false;
            }
        }
    }
}
