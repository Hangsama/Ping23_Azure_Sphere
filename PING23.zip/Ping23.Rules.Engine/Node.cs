﻿using System.Collections.Generic;

namespace Ping23.Rules.Engine
{
    public class Node
    {
        public object Value { get; set; }
        public List<Node> Next { get; set; } = new List<Node>();
    }
}
