﻿using Ping23.Common.DTO.Rules;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Ping23.Rules.Engine
{
    internal class TreeHelper
    {
        // construit un arbre de décision à partir d'un ensemble de règles
        public static Node[] Build(IEnumerable<Rule> rules)
        {
            // compter le nombre d'occurence de chaque condition pour pondérer

            var conditionWeights = new Dictionary<object, int>();
            var root = new List<Node>();

            foreach (var condition in rules.SelectMany(rule => rule.Conditions))
                if (conditionWeights.ContainsKey(condition))
                    conditionWeights[condition]++;
                else conditionWeights.Add(condition, 1);

            // construire l'arbre de façon incrémentale pour chaque règle

            foreach (var rule in rules)
            {
                var actions = new Node { Value = rule.Actions };
                Node prev = null;

                // parcourir les conditions triées par nombre d'occurences dans l'ensemble des règles pour optimiser l'arbre
                // pour chaque condition, si elle existe déjà, on se place sur le noeud au lieu de la dupliquer
                // afin de ne pas tester plusieurs fois la même condition pour une même entité
                foreach (var condition in rule.Conditions.OrderByDescending(c => conditionWeights[c]))
                    if (prev == null)
                    {
                        prev = root.SingleOrDefault(node => node.Value.Equals(condition));

                        if (prev == null)
                        {
                            prev = new Node { Value = condition };
                            root.Add(prev);
                        }
                    }
                    else
                    {
                        var next = prev.Next.SingleOrDefault(node =>
                        node.Value.Equals(condition))
                            ?? new Node { Value = condition };

                        prev.Next.Add(next);
                        prev = next;
                    }

                // ajouter les actions à la fin du chemin de conditions
                if (prev != null) prev.Next.Add(actions);
                else root.Add(actions);
            }

            return root.ToArray();
        }
    }
}
