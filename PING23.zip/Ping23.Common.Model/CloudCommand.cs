﻿namespace Ping23.Common.Model
{
    public class CloudCommand
    {
        public string Type { get; set; }
        public double Value { get; set; }
    }
}
