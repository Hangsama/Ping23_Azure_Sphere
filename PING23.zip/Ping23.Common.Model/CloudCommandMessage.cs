﻿namespace Ping23.Common.Model
{
    public class CloudCommandMessage
    {
        public string Type { get; set; }
        public double Value { get; set; }
    }
}
