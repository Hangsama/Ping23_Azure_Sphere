﻿namespace Ping23.Common.Model
{
    public class PlatformMessage
    {
        public string Type { get; set; }
        public string Origin { get; set; }
        public long Timestamp { get; set; }
    }

    public class PlatformMessage<TData> : PlatformMessage
    {
        public TData Data { get; set; }
    }

    public enum MessageType
    {
        Unknown, Reading, Command, CloudMessage, CloudCommand
    }
}
