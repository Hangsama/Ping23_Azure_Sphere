﻿namespace Ping23.Common.Model.Misc
{
    public class RedisSettings
    {
        public string ConnectionString { get; set; }
    }
}
