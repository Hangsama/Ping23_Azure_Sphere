﻿namespace Ping23.Common.Model.Misc
{
    public class IoTHubSettings
    {
        public string ConnectionString { get; set; }
    }
}
