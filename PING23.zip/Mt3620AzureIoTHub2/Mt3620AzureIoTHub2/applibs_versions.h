#pragma once
// This header defines which struct versions will be used for applibs APIs.
#define WIFICONFIG_STRUCTS_VERSION 1
#define UART_STRUCTS_VERSION 1