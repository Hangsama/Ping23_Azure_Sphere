﻿using MongoDB.Driver;

namespace Ping23.Common.Providers.MongoDB
{
    public class MongoDbProvider
    {
        public IMongoDatabase Database { get; private set; }

        public MongoDbProvider(MongoDbSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);

            Database = client.GetDatabase(settings.DatabaseName);
        }
    }
}
